package pl.codeme.oop;

public class Point {
	private char mark; //
	
	public Point(){
		this.mark='.';
	}

	public char getMark() {
		return mark;
	}

	public void setMark(char mark) {
		this.mark = mark;
	}
	
}
