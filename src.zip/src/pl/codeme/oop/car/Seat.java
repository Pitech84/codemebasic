package pl.codeme.oop.car;

public class Seat {

}
