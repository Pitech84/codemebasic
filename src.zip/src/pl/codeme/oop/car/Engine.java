package pl.codeme.oop.car;

public class Engine {

	public void start() {
		// TODO Auto-generated method stub
		
	}

}
