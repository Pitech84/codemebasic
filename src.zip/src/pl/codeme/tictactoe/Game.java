package pl.codeme.tictactoe;

import pl.codeme.tictactoe.exception.TicTacToeFieldOccupiedException;
import pl.codeme.tictactoe.exception.TicTacToeOutOfBoardException;

public class Game {

	public static void main(String[] args) {
		Player[] players = new Player[2];

		// utworzyc obiekty Player
		players[0] = new Player('X', "Marek");
		players[1] = new Player('Y', "Zbyszek");

		// utworzyc obiekt gry TicTacToe

		TicTacToe ttt = new TicTacToe(5, 5, players, 3);

		testPlay(ttt, 1, 1);
		testPlay(ttt, 1, 2);
		testPlay(ttt, 1, 1);
		testPlay(ttt, 1, 3);
		// zagrac kilka razy metoda play() i w debuggerze obserowac zmiany

		// spytac z klawiatury o rzeczy potrzebne do gry rzeczy

	}

	private static void testPlay(TicTacToe ttt, int x, int y) {
		System.out.println("Kolej gracza: " + ttt.whoseTurn().getName());
		System.out.println("Strzał: " + x + "x" + y);

		try {
			ttt.play(x, y);
		} catch (TicTacToeOutOfBoardException e) {
			System.out.println("Próbujesz strzelic poza planszę");
		} catch (TicTacToeFieldOccupiedException e) {
			System.out.println("To pole jest już zajęte");
		}
		System.out.println();
	}
}
