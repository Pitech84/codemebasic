package pl.codeme.tictactoe;

public class Player {
	private char mark;
	private String name;
	private int score; // czy szybko stawia swoje znaki
	
	
	public Player(char mark, String name) {
		super();
		this.mark = mark;
		this.name = name;
		score = 0;  		// kazdy gracz wstępie dostaje 0 punktow
	
	}
	
	public void increaseScore(int amount){
		score += amount;
	}
	public char getMark() {
		return mark;
	}
	public String getName() {
		return name;
	}
	public int getScore() {
		return score;
	}
	
	
}
