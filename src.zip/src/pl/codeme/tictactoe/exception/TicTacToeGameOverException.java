package pl.codeme.tictactoe.exception;

public class TicTacToeGameOverException extends TicTacToeException {

}
