package pl.codeme.tictactoe.exception;

public class TicTacToePlayerException extends TicTacToeException {

}
