package pl.codeme.tictactoe.exception;

public class TicTacToeOutOfBoardException extends TicTacToeBoardException {

}
