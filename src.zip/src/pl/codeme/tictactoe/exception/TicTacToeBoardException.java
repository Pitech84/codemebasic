package pl.codeme.tictactoe.exception;

public class TicTacToeBoardException extends TicTacToeException{

}
