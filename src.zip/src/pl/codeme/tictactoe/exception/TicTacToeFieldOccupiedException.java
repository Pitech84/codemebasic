package pl.codeme.tictactoe.exception;

public class TicTacToeFieldOccupiedException extends TicTacToeBoardException {

}
