package pl.codeme.tictactoe.exception;

public class TicTacToeException extends Exception {

}
