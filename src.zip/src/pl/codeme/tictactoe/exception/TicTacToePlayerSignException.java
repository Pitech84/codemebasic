package pl.codeme.tictactoe.exception;

public class TicTacToePlayerSignException extends TicTacToePlayerException {

}
